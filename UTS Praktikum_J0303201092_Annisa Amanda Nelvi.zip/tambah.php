<?php include 'layout/header.php';
if (isset($_POST['tambah'])){
    if (create_tanaman($_POST) > 0) {
        echo "<script>
                    alert('Data Barang Berhasil Ditambahkan');
                    document.location.href = 'index.php';
                </script>";
    }else {
        echo "<script>
        alert('Data Barang gagal Ditambahkan');
        document.location.href = 'index.php';
    </script>";
    }
}
?>


    <div class="container mt-5">
        <h1>Tambah Data Tanaman</h1>
        <hr>
        <form action="" method="post">

        <div class="mb-3">
            <label for="nama_tanaman" class="form-label">Nama Tanaman</label>
            <input type="text" class="form-control" id="nama_tanaman" name="namatanaman" placeholder="Nama Tanaman"
            required>
        </div>
        
        <div class="mb-3">
            <label for="nama_ilmiah" class="form-label">Nama ilmiah</label>
            <input type="text" class="form-control" id="nama_ilmiah" name="namailmiah" placeholder="Nama Ilmiah"
            required>
        </div>

        <!-- <div class="mb-3">
            <label for="jenis_tanaman" class="form-label">Jenis Tanaman</label>
            <input type="text" class="form-control" id="jenis_tanaman" name="jenistanaman" placeholder="Jenis Tanaman"
            required>
        </div> -->

        <div class="mb-3">
            <label class="form-label">Jenis Tanaman</label>
            <select class="form-select" id="jenis_tanaman" name="jenistanaman" aria-label="Default select example" required>
            <option selected disabled>Pilih Jenis</option>
            <option value="Tanaman Hias" >Tanaman Hias</option>
            <option value="Tanaman Obat" >Tanaman Obat</option>
            <option value="Tanaman Hidroponik" >Tanaman Hidroponik</option>
            <option value="Tanaman Buah" >Tanaman Buah</option>
            <option value="Tanaman Sayur" >Tanaman Sayur</option>
            </select>
        </div>



        <button type="submit" name="tambah" class="btn btn-primary" style="float: right;">Tambah</button>

        </form>
       

        
        
    </div>

    <?php include 'layout/footer.php'; ?>