<?php

$db = mysqli_connect('localhost', 'root','', 'tanaman_php');



?>
