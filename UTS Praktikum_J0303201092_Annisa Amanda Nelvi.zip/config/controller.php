<?php

//function menampilkan 
function select ($query)
{
// panggil konekci database
    global $db;

    $result = mysqli_query($db, $query);
    $rows=[];

    while ($row = mysqli_fetch_assoc($result)){
        $rows[] =$row;
    }
    return $rows;
}

//fungsi menambahkan
function create_tanaman($post)
{
    global $db;

    $nama = $post['namatanaman'];
    $ilmiah = $post['namailmiah'];
    $jenis = $post['jenistanaman'];

    //query tambah data
    $query = "INSERT INTO uplant VALUES(null, '$nama', '$ilmiah', '$jenis')";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);
}

//mengubah data barang
// function update_tanaman($post)
// {
// 	global $conn;
//     $id = $post['id_tanaman'];
// 	$nama = strip_tags($post['namatanaman']);
//     $ilmiah = strip_tags($post['namailmiah']);
// 	$jenis = strip_tags($post['jenistanaman']);
	
	
// 	$query = "UPDATE uplant SET namatanaman = '$nama', namailmiah = '$ilmiah', jenistanaman = '$jenis' WHERE id = $id_tanaman";
// 	mysqli_query($conn, $query);
// 	return mysqli_affected_rows($conn);
// }

function update_tanaman($post)
{
    global $db;
    $id_tanaman = $post['id_tanaman'];
    $nama = $post['namatanaman'];
    $ilmiah = $post['namailmiah'];
    $jenis = $post['jenis_tanaman'];

    //query 
    $query = "UPDATE uplant SET nama_tanaman = '$nama', nama_ilmiah = '$ilmiah', jenis_tanaman = '$jenis' WHERE id_tanaman = $id_tanaman";

    mysqli_query($db, $query);

    return mysqli_affected_rows($db);

}

//menghapus
function delete_tanaman($id_tanaman){
    global $db;

    $query = "DELETE FROM uplant WHERE id_tanaman = $id_tanaman";

    mysqli_query($db, $query);  

    return mysqli_affected_rows($db);
}