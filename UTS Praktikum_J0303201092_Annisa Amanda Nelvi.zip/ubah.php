<?php include 'layout/header.php';


$id = (int)$_GET['id_tanaman'];
$tanaman = SELECT("SELECT * FROM uplant WHERE id_tanaman = $id")[0];

if (isset($_POST['ubah'])){
    if (update_tanaman($_POST) > 0) {
        echo "<script>
                    alert('Data Barang Berhasil Diubah');
                    document.location.href = 'index.php';
                </script>";
    }else {
        echo "<script>
        alert('Data Barang gagal Diubah');
        document.location.href = 'index.php';
    </script>";
    }
}   
?>


    <div class="container mt-5">
        <h1>Ubah Data Tanaman</h1>
        <hr>
        <form action="" method="post">

        <div class="mb-3">

        <input type="hidden" name="id_tanaman" value="<?= $tanaman['id_tanaman']; ?>" >

            <label for="nama_tanaman" class="form-label">Nama Tanaman</label>
            <input type="text" class="form-control" id="nama_tanaman" name="namatanaman" value="<?= $tanaman['nama_tanaman']; ?>" placeholder="Nama Tanaman"
            required>
        </div>
        
        <div class="mb-3">
            <label for="nama_ilmiah" class="form-label">Nama ilmiah</label>
            <input type="text" class="form-control" id="nama_ilmiah" name="namailmiah" value="<?= $tanaman['nama_ilmiah']; ?>"placeholder="Nama Ilmiah"
            required>
        </div>

        <!-- <div class="mb-3">
            <label for="jenis_tanaman" class="form-label">Jenis Tanaman</label>
            <input type="text" class="form-control" id="jenis_tanaman" name="jenistanaman" placeholder="Jenis Tanaman"
            required>
        </div> -->

        <div class="mb-3">
            <label class="form-label">Jenis Tanaman</label>
            <select class="form-select" id="jenis_tanaman" name="jenis_tanaman" aria-label="Default select example" required>
            <option selected disabled>Pilih Jenis</option>
            <option value="Tanaman Hias" <?php echo ($tanaman['jenis_tanaman'] === 'Tanaman Hias') ? 'selected' : '' ?>>Tanaman Hias</option>
            <option value="Tanaman Obat" <?php echo ($tanaman['jenis_tanaman'] === 'Tanaman Obat') ? 'selected' : '' ?>>Tanaman Obat</option>
            <option value="Tanaman Hidroponik" <?php echo ($tanaman['jenis_tanaman'] === 'Tanaman Hidroponik') ? 'selected' : '' ?>>Tanaman Hidroponik</option>
            <option value="Tanaman Buah" <?php echo ($tanaman['jenis_tanaman'] === 'Tanaman Buah') ? 'selected' : '' ?>>Tanaman Buah</option>
            <option value="Tanaman Sayur" <?php echo ($tanaman['jenis_tanaman'] === 'Tanaman Sayur') ? 'selected' : '' ?>>Tanaman Sayur</option>
            </select required>
        </div>



        <button type="submit" name="ubah" class="btn btn-primary" style="float: right;">Ubah</button>

        </form>
       

        
        
    </div>

    <?php include 'layout/footer.php'; ?>
