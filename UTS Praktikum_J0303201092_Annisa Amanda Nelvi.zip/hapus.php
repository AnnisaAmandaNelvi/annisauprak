<?php

include 'config/app.php';

$id_tanaman = (int)$_GET['id_tanaman'];
if (delete_tanaman($id_tanaman) > 0 ){
    echo "<script>
        alert('Data Barang Berhasil Dihapus');
        document.location.href = 'index.php';
        </script>";

} else {
    echo "<script>
        alert('Data Barang Gagal Dihapus');
        document.location.href = 'index.php';
        </script>";
}
?>